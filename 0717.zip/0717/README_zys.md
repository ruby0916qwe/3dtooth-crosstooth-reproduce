### Data
`data`: contains the Teeth3DS dataset
```
data
    | downsampled_upper
    | downsampled_lower
    | lower
    | upper
    | downsample.py

```
- `lower`, `upper`: Teeth3DS point cloud files in `.ply` format  
- `downsampled_lower`, `downsampled_upper`: downsampled Teeth3DS `.ply` datasets  
- `downsample.py`: script for QEM-based downsampling

### Usage

- `utils.py`, `dataset/data.py`: have been modified
- `process.py`: converts the original Teeth3DS dataset (OBJ and JSON files) from the Downloads folder into `.ply` format, saved under `lower` and `upper` directories
- `metircs.py`: contains functions that are called to compute evaluation metrics results
### Experiment
(Specify `version` to indicate experiment version)

Step 1: Data splitting before training

```commandline
python data_split.py 
```
Step 2: Train the model

```commandline
python train.py 
```
Step 3: Run inference (prediction)

```commandline
python inference.py --pretrain_model_path ...
```
predicted ply files would be saved under `experiment/{version}/inference_results`

Step 4: Evaluate metrics by comparing predicted `.ply` files in `experiment/{version}/inference_results`  
with ground truth files in `experiment/{version}/test`.
```commandline
python test.py 
```

