import numpy as np
from plyfile import PlyData
from sklearn.neighbors import NearestNeighbors
from utils import color2label

def read_ply_face_center_and_labels(ply_path):
    plydata = PlyData.read(ply_path)
    face = plydata['face']
    vertex = plydata['vertex']

    vertices = np.vstack((vertex['x'], vertex['y'], vertex['z'])).T  # (V, 3)
    face_indices = face['vertex_indices']  # (F, 3)

    # calculate face center coordinate
    face_centers = np.array([vertices[idxs].mean(axis=0) for idxs in face_indices])  # (F, 3)

    # mapping color to label
    colors = np.stack([face['red'], face['green'], face['blue']], axis=1)
    labels = np.array([color2label[tuple(c)][2] for c in colors], dtype=np.int32)
    return face_centers, labels

def calculate_miou_per_class(gt_labels, pred_labels, target_class):

    gt_mask = (gt_labels == target_class)
    pred_mask = (pred_labels == target_class)

    intersection = np.logical_and(gt_mask, pred_mask).sum()
    union = np.logical_or(gt_mask, pred_mask).sum()
    miou = intersection / (union + 1e-6) if union > 0 else 1.0
    return miou


def calculate_miou(gt_labels, pred_labels, n_class=17, include_background=False):
    ious = []
    weights = []

    start_class = 0 if include_background else 1

    for c in range(start_class, n_class):
        iou = calculate_miou_per_class(gt_labels, pred_labels, target_class=c)
        ious.append(iou)
        weights.append((gt_labels == c).sum())

    weights = np.array(weights, dtype=np.float32)

    if weights.sum() == 0:
        return 0.0, 0.0 if include_background else (0.0, None)

    weighted_miou = np.sum(np.array(ious) * weights) / weights.sum()

    iou_0 = calculate_miou_per_class(gt_labels, pred_labels, target_class=0)
    
    return weighted_miou, iou_0

def compute_boundary_mask(face_centers, labels, k=8):
    """
    向量化计算边界点mask。
    - face_centers: (F, 3)
    - labels: (F,)
    返回 bool数组，True表示边界点
    """
    nbrs = NearestNeighbors(n_neighbors=k+1, algorithm='auto').fit(face_centers)
    _, indices = nbrs.kneighbors(face_centers)  # (F, k+1)
    
    # 取出邻居标签，shape=(F, k+1)
    neighbor_labels = labels[indices]

    # 中心点标签扩展到邻居维度，shape=(F, 1)
    center_labels = labels[:, np.newaxis]

    # 判断邻居标签是否与中心点标签相等，shape=(F, k+1)
    equal_mask = (neighbor_labels == center_labels)

    # 排除自己（第0个邻居即自身）
    equal_mask = equal_mask[:, 1:]  # shape=(F, k)

    # 计算与中心点标签不相等的邻居数量
    diff_count = np.sum(~equal_mask, axis=1)  # shape=(F,)

    # 多数邻居标签不同则为边界点
    boundary_mask = diff_count > (k / 2)

    return boundary_mask

def calculate_boundary_miou(gt_centers, gt_labels, pred_labels, n_class, k=8):

    gt_boundary = compute_boundary_mask(gt_centers, gt_labels, k)

    gt_boundary_labels = gt_labels[gt_boundary]
    pred_boundary_labels = pred_labels[gt_boundary]

    weighted_miou,_ = calculate_miou(gt_boundary_labels, pred_boundary_labels, n_class=17, include_background=True)

    return weighted_miou

def evaluate_segmentation(pred_ply_path, gt_ply_path, n_class=17):

    pred_centers, pred_labels = read_ply_face_center_and_labels(pred_ply_path)
    gt_centers, gt_labels = read_ply_face_center_and_labels(gt_ply_path)

    if len(pred_labels) != len(gt_labels):
        raise ValueError(f"预测和GT面数不一致！预测数={len(pred_labels)}, GT数={len(gt_labels)}")

    # acc = np.sum(pred_labels == gt_labels) / len(gt_labels)
    weighted_miou, iou_0 = calculate_miou(gt_labels, pred_labels, n_class, include_background=False)
    
    boundary_miou = calculate_boundary_miou(
        gt_centers, gt_labels, pred_labels, n_class, k=8
    )

    merge_pairs = [
        (1, 9), (2, 10), (3, 11), (4, 12), (5, 13), (6, 14), (7, 15)
    ]
    merged_ious = {}
    for a, b in merge_pairs:
        gt_merge = (gt_labels == a) | (gt_labels == b)
        pred_merge = (pred_labels == a) | (pred_labels == b)
        intersection = np.logical_and(gt_merge, pred_merge).sum()
        union = np.logical_or(gt_merge, pred_merge).sum()
        iou = intersection / (union + 1e-6) if union > 0 else 1.0
        merged_ious[f"T{a}/T{b}"] = iou

    results = {
        # "accuracy": acc,
        "weighted_miou": weighted_miou,
        "merged_ious": merged_ious,
        "boundary_miou": boundary_miou,
        "background_iou": iou_0,
    }
    return results