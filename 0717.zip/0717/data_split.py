import os
import shutil
import random

def collect_files(folder):
    return [os.path.join(folder, f) for f in os.listdir(folder) if os.path.isfile(os.path.join(folder, f))]

def count_lower_upper(folder):
    files = os.listdir(folder)
    lower_count = sum(1 for f in files if "lower" in f.lower())
    upper_count = sum(1 for f in files if "upper" in f.lower())
    return lower_count, upper_count

def split_and_copy(files, train_folder, test_folder, train_num=1440, test_num=360):
    total_needed = train_num + test_num
    if len(files) < total_needed:
        raise ValueError(f"Not enough files. Required {total_needed}, found {len(files)}")

    random.shuffle(files)

    train_files = files[:train_num]
    test_files = files[train_num:train_num+test_num]

    os.makedirs(train_folder, exist_ok=True)
    os.makedirs(test_folder, exist_ok=True)

    for f in train_files:
        shutil.copy(f, os.path.join(train_folder, os.path.basename(f)))
    for f in test_files:
        shutil.copy(f, os.path.join(test_folder, os.path.basename(f)))

    print(f"Copied {len(train_files)} files to {train_folder}")
    print(f"Copied {len(test_files)} files to {test_folder}")

    # Count lower and upper files in train folder
    train_lower, train_upper = count_lower_upper(train_folder)
    print(f"Train set: lower: {train_lower}, upper: {train_upper}.")

    # Count lower and upper files in test folder
    test_lower, test_upper = count_lower_upper(test_folder)
    print(f"Test set: lower: {test_lower}, upper: {test_upper}.")

def main():
    version = input("Please input version number (e.g., 1): ").strip()
    if not version.isdigit():
        raise ValueError("Version must be a numeric string")

    lower_folder = "data/downsampled_lower"
    upper_folder = "data/downsampled_upper"

    all_files = collect_files(lower_folder) + collect_files(upper_folder)
    print(f"Total combined files: {len(all_files)}")

    base_dir = os.path.join("experiment", version)
    train_dir = os.path.join(base_dir, "train")
    test_dir = os.path.join(base_dir, "test")

    split_and_copy(all_files, train_dir, test_dir, train_num=1440, test_num=360)

if __name__ == "__main__":
    main()