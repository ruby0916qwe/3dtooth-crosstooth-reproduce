import os
import argparse
import torch
import numpy as np

from models.PTv1.point_transformer_seg import PointTransformerSeg38
from utils import output_pred_ply
from utils import label2color_lower, label2color_upper
from dataset.data import ToothData
import vedo


def do_predict_all(args):
    device = torch.device("cuda" if args.cuda else "cpu")

    enable_pic_feat = False
    point_model = PointTransformerSeg38(
        in_channels=6, num_classes=17, pretrain=False,
        add_cbl=False, enable_pic_feat=enable_pic_feat
    ).to(device)

    pretrained_dict = torch.load(args.pretrain_model_path, map_location=device)
    point_model.load_state_dict(pretrained_dict)
    
    upper_palette = np.array(
        [[255, 255, 255]] +
        [[label2color_upper[label][2][0],
        label2color_upper[label][2][1],
        label2color_upper[label][2][2]]
        for label in range(1, 17)], dtype=np.uint8)

    lower_palette = np.array(
        [[255, 255, 255]] +
        [[label2color_lower[label][2][0],
        label2color_lower[label][2][1],
        label2color_lower[label][2][2]]
        for label in range(1, 17)], dtype=np.uint8)

    # Load all test files
    test_files = []
    if args.test_dir:
        test_files = [os.path.join(args.test_dir, f) for f in os.listdir(args.test_dir) if f.endswith('.ply')]

    print(f"Total {len(test_files)} samples in the test set")

    # Create output directory
    os.makedirs(args.save_dir, exist_ok=True)

    point_model.eval()
    with torch.no_grad():
        for ply_path in test_files:
            print(f"Processing {ply_path} ...")
            
            base_name = os.path.basename(ply_path).lower()
            if "upper" in base_name:
                palette = upper_palette

            elif "lower" in base_name:
                palette = lower_palette

            else:
                print(f"Warning: File '{base_name}' does not contain 'upper' or 'lower' info, using default lower palette")
                palette = lower_palette

            dataset = ToothData(args, [ply_path], with_label=False)
            pointcloud, face_info = dataset.get_by_name(ply_path)
            pointcloud = pointcloud.unsqueeze(0).to(device)
            pointcloud = pointcloud.permute(0, 2, 1).contiguous()

            if enable_pic_feat:
                point_seg_result, edge_seg_result = point_model(pointcloud, None)
            else:
                point_seg_result, edge_seg_result = point_model(pointcloud)

            pred_softmax = torch.nn.functional.softmax(point_seg_result, dim=1)
            _, pred_classes = torch.max(pred_softmax, dim=1)

            pred_mask = pred_classes.squeeze(0).cpu().numpy().astype(np.uint8)

            mesh = vedo.load(ply_path)
            point_coords = np.array(mesh.points())
            face_info = np.array(mesh.cells())
            pred_mask_rgb = palette[pred_mask]

            save_path = os.path.join(args.save_dir, f"{os.path.splitext(os.path.basename(ply_path))[0]}_mask.ply")
            output_pred_ply(pred_mask_rgb, None, save_path, point_coords, face_info)

            print(f"Saved prediction to {save_path}")

def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--test_dir', type=str, default=None, help='Directory containing test point cloud files')
    parser.add_argument('--save_dir', type=str, default=None, help='Directory to save prediction results')
    parser.add_argument('--pretrain_model_path', type=str, default='experiment/1/checkpoints/point_transformer_epoch40.pth', help='Path to the pretrained model')
    parser.add_argument('--no_cuda', action='store_true', help='Disable GPU')
    parser.add_argument('--num_points', type=int, default=16000)
    parser.add_argument('--sample_points', type=int, default=16000)
    return parser.parse_args()

if __name__ == "__main__":
    version = input("Please input version number (e.g., 1): ").strip()
    if not version.isdigit():
        raise ValueError("Version must be a numeric string")

    args = get_args()

    # Use command line arguments if provided, otherwise construct paths based on version
    if args.test_dir is None:
        args.test_dir = os.path.join("experiment", version, "test")
    if args.save_dir is None:
        args.save_dir = os.path.join("experiment", version, "inference_results")

    print(f"Using test_dir: {args.test_dir}")
    print(f"Using save_dir: {args.save_dir}")

    args.cuda = (not args.no_cuda) and torch.cuda.is_available()
    torch.manual_seed(1)
    if args.cuda:
        torch.cuda.manual_seed(1)

    do_predict_all(args)