import os
import argparse
from metrics import evaluate_segmentation
import numpy as np

def get_args():
    parser = argparse.ArgumentParser(description="Batch evaluate segmentation performance for prediction and GT PLY folders")
    parser.add_argument("--pred_dir", type=str, default=None, help="Folder path of predicted PLY files")
    parser.add_argument("--gt_dir", type=str, default=None, help="Folder path of ground truth PLY files")
    parser.add_argument("--num_classes", type=int, default=17, help="Number of classes (including background)")
    return parser.parse_args()

def evaluate_folder_pair(pred_folder, gt_folder, num_classes=17):
    
    pred_files = sorted([f for f in os.listdir(pred_folder) if f.endswith('.ply')])
    gt_files = sorted([f for f in os.listdir(gt_folder) if f.endswith('.ply')])

    if len(pred_files) == 0:
        raise RuntimeError(f"No PLY files found in prediction folder: {pred_folder}")
    if len(gt_files) == 0:
        raise RuntimeError(f"No PLY files found in ground truth folder: {gt_folder}")

    if len(pred_files) != len(gt_files):
        print(f"Warning: Number of prediction and GT files differ: {len(pred_files)} vs {len(gt_files)}. Matching by the smaller count.")

    n = min(len(pred_files), len(gt_files))

    weighted_miou_list = []
    background_ious = []  
    boundary_miou_list = []  
    merged_ious = None
    
    for i in range(n):
        pred_path = os.path.join(pred_folder, pred_files[i])
        gt_path = os.path.join(gt_folder, gt_files[i])

        results = evaluate_segmentation(pred_path, gt_path, n_class=num_classes)

        weighted_miou_list.append(results['weighted_miou'])
        boundary_miou_list.append(results['boundary_miou'])  
        background_ious.append(results['background_iou']) 

        if merged_ious is None:
            merged_ious = {k: 0.0 for k in results['merged_ious'].keys()}

        for k, v in results['merged_ious'].items():
            merged_ious[k] += v

    miou = np.mean(weighted_miou_list) if weighted_miou_list else 0.0
    background_miou = np.mean(background_ious) if background_ious else 0.0  
    boundary_miou = np.mean(boundary_miou_list) if boundary_miou_list else 0.0
    count = len(weighted_miou_list)

    print(f"\nTotal evaluated samples: {count}")
    print(f"Mean IoU (excluding background): {miou:.4f}")
    print(f"Background IoU: {background_miou:.4f}")  
    print(f"Boundary IoU: {boundary_miou:.4f}") 
    print("\nMerged class pair IoUs (left-right pairs):")
    if merged_ious and count > 0:
        for k, v in merged_ious.items():
            print(f"Class {k} merged IoU: {v / count:.4f}")
    else:
        print("No merged class pair IoU results.")

def main():
    version = input("Please input version number (e.g., 1): ").strip()
    if not version.isdigit():
        raise ValueError("Version must be a numeric string")

    args = get_args()

    if args.pred_dir is None:
        args.pred_dir = os.path.join("experiment", version, "inference_results")
    if args.gt_dir is None:
        args.gt_dir = os.path.join("experiment", version, "test")

    print(f"Using prediction directory: {args.pred_dir}")
    print(f"Using ground truth directory: {args.gt_dir}")

    evaluate_folder_pair(args.pred_dir, args.gt_dir, args.num_classes)

if __name__ == "__main__":
    main()